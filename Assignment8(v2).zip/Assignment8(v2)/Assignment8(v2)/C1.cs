﻿using System;

namespace Assignment8_v2_
{
    class C1 : IMyInterface

    {
        private double _loanAmount = 0.0;
        private double _years = 0.0;
        private double _interests = 0.0;
        private double _interestRate = 0.0;

        public static void Main()
        {
            Console.WriteLine("\t\tMorgage Loan Calculator");
            Console.WriteLine("--------------------------------------------------");
            Console.Write("Enter Loan Amount: ");
            double loanAmount = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the amount of years: ");
            double Years = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter interest rate: ");
            double interestRate = Convert.ToDouble(Console.ReadLine());
            C1 Calculations = new C1(loanAmount, Years, interestRate);
            Console.WriteLine("Total Intetrests: ${0}", Calculations.PayInterests());
            Console.WriteLine(Calculations.IMessage());
        }


        //Constructor 1
        public C1(double loanAmount, double Years, double interestRate)
        {
            _loanAmount = loanAmount;
            _years = Years;
            _interestRate = interestRate;
        }


        //Method 1 
        public double PayInterests()
        {
            double Interests = _loanAmount * _interestRate * _years;
            return Interests;
        }


        //Method 2
        public string IMessage()
        {
            return("Be ready!");
        }


        //Public Properties
        public double loanAmount
        {
            get
            {
                return _loanAmount;
            }
        }

        public double Years
        {
            get
            {
                return _years;
            }
        }

        public double Interests
        {
            get
            {
                return _interests;
            }
        }

        public double interestRate
        {
            get
            {
                return _interestRate;
            }
        }
    }
}
