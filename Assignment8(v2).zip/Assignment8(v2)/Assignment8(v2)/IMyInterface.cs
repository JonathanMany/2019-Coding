﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment8_v2_
{
    interface IMyInterface
    {
                string IMessage();
    }
}
