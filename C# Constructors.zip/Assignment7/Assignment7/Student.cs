﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment7
{
    class Student
    {
        public static int Count; //On the instructions this isnt supposed to be a public, cannot write line due to access level
        private static readonly Random rnd = new Random();
        private string _firstName;
        private string _lastName;
        private int _sID;

        //Constructor 1 
        public Student(string first, string last, int id)
        {
            _firstName = first;
            _lastName = last;
            _sID = id;
            Count++;
        }

        //Constructor 2
        public Student(string first = "", string last = "")
        {
            _firstName = first;
            _lastName = last;
            _sID = rnd.Next(1000, 9999);
            Count++;
        }

        // Public Properties 
        public string firstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }
        public string lastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }
        public int sID
        {
            get
            {
                return _sID;
            }
            set
            {
                _sID = value;
            }
        }
    }
}
