﻿using System;
using System.Collections.Generic;

namespace Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Student> myList = new List<Student>();
            Student s1 = new Student();
            s1.firstName = "John";
            s1.lastName = "Smith";
            s1.sID = 2560;
            myList.Add(s1);

            Student s2 = new Student("Peter");
            myList.Add(s2);


            Student s3 = new Student("Morgan", "Simmons");
            myList.Add(s3);

            Student s4 = new Student("James", "Walters");
            myList.Add(s4);

            Student s5 = new Student("Linda", "Scott", 1005);
            myList.Add(s5);


            Console.WriteLine();

            Console.WriteLine("Total students: {0}", Student.Count); //On the instructions this isnt supposed to be a public, cannot write line due to access level
            foreach (Student stdnt in myList)
            {
                Console.WriteLine("Name: {0} {1}, Student ID: {2}", stdnt.firstName, stdnt.lastName, stdnt.sID);
            }
        }

    }
}
