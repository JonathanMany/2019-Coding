﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
            Campus atc = new Campus("Advanced Technology College");


            Console.WriteLine(atc.ToString());
        }
    }
}
