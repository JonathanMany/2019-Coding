﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment8
{
    class Campus : DSC
    {
        private string campusName;
        public string getCampusName
        {
            get
            {
                return campusName;
            }
        }
        public Campus(string cName)
        {
            campusName = cName; 
        }
        public virtual string showAddress()
        {
            return "1770 Williamson Blvd., Daytona Beach, Florida 32117 ";
        }

        public string Departments()
        {
            return "Computer Scinece Department, Emergency Care Department, Police Academy";
        }

        public string ToString()
        {
            return "\t" + getSchoolName + campusName + "\nis located at "+ showAddress() + "\nit has " + Departments();

        }
    }
}
