﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment8
{
    class DSC
    {
        private string schoolName = "Daytona State College ";
        public string getSchoolName
        {
            get
            {
                return schoolName;
            }
        }

        public virtual string showAddress()
        {
            return " 1200 W. International Speedway Blvd., Daytona Beach, Florida 32114 ";
        }
    }
}
