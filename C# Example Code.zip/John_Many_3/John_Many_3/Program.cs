﻿using John_Many_3;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
            Student[] students = new Student[4] {
                new ElementarySchoolStudent("David", "Hunt", "1"),
                new MiddleSchoolStudent("Mike", "Trout", "2"),
                new HighSchoolStudent("John", "Many", "3"),
                new CollegeStudent("Mary", "Hopkins", "4")
               
            };
            for (int i = 0; i < students.Length; i++)
            {


             Console.WriteLine(students[i].ToString());

            }

            
        }
    }
}
