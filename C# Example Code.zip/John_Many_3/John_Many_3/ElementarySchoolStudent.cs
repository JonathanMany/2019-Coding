﻿using System;
using System.Collections.Generic;
using System.Text;

namespace John_Many_3
{
    class ElementarySchoolStudent : Student, IMathClass
    {

        public ElementarySchoolStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID)
        {

        }
        public override string ImportantThing()
        {
            return "Farm Field Trip!";
        }
        public string Math()
        {
            return "Basic Math!";
        }
        public override string ToString()
        {
            return "My name is " + firstName + " " + lastName + ", I am an Elementary School Student. I will have an exciting " + ImportantThing() + ", I will learn " + Math() + ".";
        }
    }
}
