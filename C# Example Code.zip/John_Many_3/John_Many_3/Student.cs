﻿using System;
using System.Collections.Generic;
using System.Text;

namespace John_Many_3
{
    abstract class Student
    {
        //Public Data Members 
        public string firstName;
        public string lastName;
        public string studentID;
  
        /*I did not see a reason to make a readonly property for something that is
         already is public, and due to this I was getting errors I could not work around
         I am free to discuss this with you on maybe something that I missed while creating this
         program and following the instructuctions. Thank you for your time
        */
        

        //Constructor
        public Student(string _firstName, string _lastName, string _studentID)
        {
            firstName = _firstName;
            lastName = _lastName;
            studentID = _studentID;
        }

        //Abstract Method 
        public abstract string ImportantThing();

    }
}
