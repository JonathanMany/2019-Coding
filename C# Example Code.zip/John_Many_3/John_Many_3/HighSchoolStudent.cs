﻿using System;
using System.Collections.Generic;
using System.Text;

namespace John_Many_3
{
    class HighSchoolStudent : Student, IMathClass
    {

        public HighSchoolStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID)
        {

        }
        public override string ImportantThing()
        {
            return "SAT Exam!";
        }
        public string Math()
        {
            return "Basic Algebra!";
        }
        public override string ToString()
        {
            return "My name is " + firstName + " " + lastName + ", I am a High School Student. I will take a " + ImportantThing() + ", I will learn " + Math() + ".";
        }
    }
}
