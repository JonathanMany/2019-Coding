﻿using System;
using System.Collections.Generic;
using System.Text;

namespace John_Many_3
{
    class CollegeStudent : Student, IMathClass
    {

        public CollegeStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID)
        {

        }
        public override string ImportantThing()
        {
            return "Major";
        }
        public string Math()
        {
            return "Advanced Algebra!";
        }
        public override string ToString()
        {
            return "My name is " + firstName + " " + lastName + ", I am a College Student. I will have a " + ImportantThing() + ", I will learn " + Math() + ".";
        }
    }
}
