﻿using System;
using System.Collections.Generic;
using System.Text;

namespace John_Many_3
{
    interface IMathClass
    {
        public abstract string Math();
    }
}
