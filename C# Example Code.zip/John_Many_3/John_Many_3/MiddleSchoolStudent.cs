﻿using System;
using System.Collections.Generic;
using System.Text;

namespace John_Many_3
{
    class MiddleSchoolStudent : Student, IMathClass
    { 

        public MiddleSchoolStudent(string firstName, string lastName, string studentID) : base(firstName, lastName, studentID)
        {

        }
        public override string ImportantThing()
        {
            return "Summer Camp!";
        }
        public string Math()
        {
            return "Geometry!";
        }
        public override string ToString()
        {
            return "My name is " + firstName + " " + lastName + ", I am a Middle School Student. I will have a " + ImportantThing() + ", I will learn " + Math() + ".";
        }
    }
}
