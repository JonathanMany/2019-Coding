﻿using System;

namespace Assignment10
{
    class C1 : MyRangeException, IMyInterface

    {
        private double _loanAmount = 0.0;
        private double _years = 0.0;
        private double _interests = 0.0;
        private double _interestRate = 0.0;
     
       
        //Constructor 1
        public C1(double loanAmount, double Years, double interestRate)
        {
            _loanAmount = loanAmount;
            _years = Years;
            _interestRate = interestRate;
        }


        //Method 1 
        public double PayInterests()
        {

            double Interests = _loanAmount * _interestRate * _years;
            return Interests;

        }


        //Method 2
        public string IMessage()
        {
            return("Be ready!");
        }


        //Public Properties
        public double loanAmount
        {
            get
            {
                return _loanAmount;
            }
        }

        public double Years
        {
            get
            {
                return _years;
            }
        }

        public double Interests
        {
            get
            {
                return _interests;
            }
        }

        public double interestRate
        {
            get
            {
                return _interestRate;
            }
        }
    }
}
