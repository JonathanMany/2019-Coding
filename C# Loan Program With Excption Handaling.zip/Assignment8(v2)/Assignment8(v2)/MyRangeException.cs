﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment10
{
    public class MyRangeException : Exception
    {
        public MyRangeException()
        {

        }

        public MyRangeException(string message) : base(message)
        {

        }

    }
}
