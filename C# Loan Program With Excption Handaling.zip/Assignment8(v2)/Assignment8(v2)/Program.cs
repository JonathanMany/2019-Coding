﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment10
{
    class Program 

    {
        public static double loanAmount;
        public static double Years;
        public static double interestRate;
        public static void CheckLoanAmount(double la)
        {
            if (la < 50000)
            {
                throw new MyRangeException("Loan Amount must be $50,000 or more.");
            }
        }
        public static void CheckYearAmount(double ly)
        {
            if (ly < 5)
            {
                throw new MyRangeException("Years must be 5 years or more.");
            }
        }
        public static void CheckInterestAmount(double li)
        {
            if (li < 0.01)
            {
                throw new MyRangeException("Interest Rate must be 1% or more.");
            }
        }
        public static void Main()
        {
            bool continueLoop = true;
            Console.WriteLine("\t\tMorgage Loan Calculator");
            Console.WriteLine("--------------------------------------------------");


            //Loan Amount 
            do
            {
                try
                {
                    Console.Write("Enter Loan Amount: ");
                    loanAmount = Convert.ToDouble(Console.ReadLine());
                    CheckLoanAmount(loanAmount);
                    continueLoop = false;
                }
                catch (FormatException formatException)
                {
                    Console.WriteLine("\n" + formatException.Message);
                    Console.WriteLine("Please enter a double value.\n");
                }
                catch (MyRangeException negativeNumberException)
                {
                    Console.WriteLine("\n" + negativeNumberException.Message);
                    Console.WriteLine("Please enter a value greater than $50,000\n");
                }
            } while (continueLoop);

            continueLoop = true;

            //Years
            do
            {
                try
                {
                    Console.Write("Enter the amount of years: ");
                    Years = Convert.ToDouble(Console.ReadLine());
                    CheckYearAmount(Years);
                    continueLoop = false;
                }
                catch (FormatException formatException)
                {
                    Console.WriteLine("\n" + formatException.Message);
                    Console.WriteLine("Please enter a double value.\n");
                }
                catch (MyRangeException negativeNumberException)
                {
                    Console.WriteLine("\n" + negativeNumberException.Message);
                    Console.WriteLine("Please enter a value greater than 5\n");
                }
            } while (continueLoop);

            continueLoop = true;

            //Interest
            do
            {
                try
                {
                    Console.Write("Enter interest rate: ");
                    interestRate = Convert.ToDouble(Console.ReadLine());
                    CheckInterestAmount(interestRate);
                    continueLoop = false;
                }
                catch (FormatException formatException)
                {
                    Console.WriteLine("\n" + formatException.Message);
                    Console.WriteLine("Please enter an interest rate that is greater than 1%\n");
                }
                catch (MyRangeException negativeNumberException)
                {
                    Console.WriteLine("\n" + negativeNumberException.Message);
                    Console.WriteLine("Please enter a non-negative value.\n");
                }
            } while (continueLoop);


            C1 Calculations = new C1(loanAmount, Years, interestRate);
            Console.WriteLine("Total Intetrests: ${0}", Calculations.PayInterests());
            Console.WriteLine(Calculations.IMessage());
        }
    }
}
