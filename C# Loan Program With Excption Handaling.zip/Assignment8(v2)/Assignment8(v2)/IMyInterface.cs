﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment10
{
    interface IMyInterface
    {
                string IMessage();
    }
}
