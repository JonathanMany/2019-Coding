﻿using System;
using System.Text.RegularExpressions;

namespace Assignment_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex rt = new Regex(@"^[0-9]{12,19}$");
            Regex rx = new Regex(@"^[A-z]{2,15}\s[A-z]{2,15}$", RegexOptions.Compiled);
            /*This was slightly rewriteen due to the MyDaytonaState portal having formatting issues. Could not copy the epxressions given, was able to make
              a very similar expression that did the same thing  
            */
            
            do
            {
                Console.Write("Please enter your name: ");
                string nameInput = Console.ReadLine();

                Match match = rx.Match(nameInput);

                if (!match.Success)
                {
                   Console.WriteLine("\nInvalid Crednentials, please use only spaces and letters!\n");
                }
                else 
                {
                    break;
                }       
            } while (true);

            do
            {
                Console.Write("Please enter your card number: ");
                string cardInput = Console.ReadLine();

                Match match = rt.Match(cardInput);

                if (!match.Success)
                {
                    Console.WriteLine("\nInvalid Crednentials, please use number 0-9 and please be sure to use the correct length of your card number!\n");
                }
                else
                {
                    break;
                }
            } while (true);


        }
    }
}
